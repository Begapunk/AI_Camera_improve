<template>
  <view class="container">
    <view class="logo-title">万能拍</view>

    <view class="form-box">
      <view class="title">注册新账号</view>

      <view class="form-group">
        <input
          type="text"
          placeholder="请输入用户名"
          v-model="username"
          class="input"
        />
      </view>

      <view class="form-group">
        <input
          type="password"
          placeholder="请输入密码"
          v-model="password"
          class="input"
        />
      </view>

      <view class="form-group">
        <input
          type="password"
          placeholder="请确认密码"
          v-model="confirmPassword"
          class="input"
        />
      </view>
    </view>

    <button @click="onRegister" class="btn">注册</button>

    <view class="to-login">
      已有账号？
      <navigator url="/pages/login/index" class="link">去登录</navigator>
    </view>

    <view v-if="message" class="message">{{ message }}</view>
  </view>
</template>

<script setup>
import { ref } from 'vue'
import { registerApi } from '@/utils/request.js' 

const username = ref('')
const password = ref('')
const confirmPassword = ref('')
const message  = ref('')

async function onRegister () {
  if (!username.value || !password.value || !confirmPassword.value) {
    message.value = '请完整填写信息'
    return
  }
  if (password.value !== confirmPassword.value) {
    message.value = '两次密码不一致'
    return
  }
  message.value = ''

  uni.showLoading({ title: '注册中...', mask: true })
  try {
    const res = await registerApi(username.value, password.value)  
    uni.hideLoading()

    if (res.statusCode === 200 && res.data.message) {
      uni.showToast({ title: '注册成功', icon: 'success' })
      setTimeout(() => {
        uni.redirectTo({ url: '/pages/login/index' })
      }, 1000)
    } else {
      message.value = res.data.error || res.data.message || '注册失败'
    }
  } catch (err) {
    uni.hideLoading()
    console.error(err)
    message.value = '请求失败，请稍后重试'
  }
}
</script>


<style scoped>
/* 主题色板 */
:root {
  --primary:       #1E80FF;  /* 主色 */
  --primary-dark:  #166DFF;  /* 深 */
  --primary-light: #A9C9FF;  /* 浅 */
}

.container {
  height: 100vh;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  padding: 0 24px;
  box-sizing: border-box;
  background-color: #f1f6ff;        /* 轻微蓝色底 */
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen,
    Ubuntu, Cantarell, "Open Sans", "Helvetica Neue", sans-serif;
}

.logo-title {
  font-size: 40px;
  font-weight: 900;
  background: linear-gradient(45deg, #1E80FF, #74B9FF);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  margin-bottom: 24px;
  user-select: none;
  text-shadow: 0 0 10px rgba(30, 128, 255, 0.5);
}

.form-box {
  width: 90%;
  max-width: 380px;
  padding: 24px;
  border: 1.5px solid var(--primary-light);
  border-radius: 12px;
  background-color: #ffffff;
  box-shadow: 0 4px 12px rgba(30, 128, 255, 0.1);
  margin-bottom: 20px;
}

.title {
  font-size: 24px;
  font-weight: 600;
  margin-bottom: 32px;
  color: var(--primary-dark);       /* 标题蓝 */
  user-select: none;
}

.form-group {
  width: 100%;
  max-width: 360px;
  margin-bottom: 20px;
}

.input {
  width: 90%;
  padding: 12px 16px;
  font-size: 16px;
  border: 1.8px solid var(--primary-light);
  border-radius: 8px;
  outline: none;
  background-color: white;
  transition: border-color 0.3s, box-shadow 0.3s;
}

.input::placeholder {
  color: #9ab6e8;
}

.input:focus {
  border-color: var(--primary);
  box-shadow: 0 0 8px rgba(30, 128, 255, 0.35);
}

.btn {
  width: 100%;
  max-width: 360px;
  padding: 5px 0;
  background-color: var(--primary);
  color: #fff;
  border: none;
  border-radius: 8px;
  font-weight: 600;
  font-size: 18px;
  cursor: pointer;
  user-select: none;
  transition: background-color 0.3s;
}

.btn:active {
  background-color: var(--primary-dark);
}

.to-login {
  margin-top: 24px;
  font-size: 14px;
  color: #4d6fae;
  user-select: none;
}

.link {
  color: var(--primary);
  margin-left: 6px;
  text-decoration: underline;
  user-select: none;
}

.message {
  margin-top: 18px;
  color: #e74c3c;  /* 错误提示保留红色 */
  font-size: 15px;
  font-weight: 500;
  user-select: none;
}
</style>
