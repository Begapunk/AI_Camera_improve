<template>
  <view class="home-container">
    <text class="welcome">欢迎，{{ username }}</text>
    <text class="sub-title">  万能拍将给您带来更好的自拍建议，帮您轻松捕捉最佳姿势和光线。</text>
	<text class="sub-title">  无论是日常自拍还是重要时刻，都能让您的照片更具专业感。快来体验，发现更美的自己吧！</text>

    <button @tap="goToAnalyze">
      <uni-icons type="person-filled" size="20" color="#fff" class="icon" />
      自拍建议分析
    </button>

    <button @tap="goToEnvironment">
      <uni-icons type="compass" size="20" color="#fff" class="icon" />
      环境分析
    </button>

    <button @tap="goToTemplate">
      <uni-icons type="list" size="20" color="#fff" class="icon" />
      模板评分分析
    </button>

    <button @tap="goToTemplateCollection">
      <uni-icons type="folder" size="20" color="#fff" class="icon" />
      模板合集
    </button>
  </view>
</template>

<script>
export default {
  data() {
    return {
      username: ''
    }
  },
  onShow() {
    this.username = uni.getStorageSync('username') || '用户'
  },
  methods: {
    goToAnalyze() {
      uni.navigateTo({ url: '/pages/analyze/index' })
    },
    goToEnvironment() {
      uni.navigateTo({ url: '/pages/environment/index' })
    },
    goToTemplate() {
      uni.navigateTo({ url: '/pages/template/index' })
    },
    goToTemplateCollection() {
      uni.navigateTo({ url: '/pages/template/templateCollection' })
    }
  }
}
</script>

<style scoped>
:root {
  --primary: #1E80FF;
  --primary-dark: #166DFF;
}

.home-container {
  height: 100vh;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  padding: 0 24px;
  box-sizing: border-box;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen,
    Ubuntu, Cantarell, "Open Sans", "Helvetica Neue", sans-serif;

  background:
    radial-gradient(circle at top left, rgba(140, 190, 255, 0.3), transparent 60%),
    radial-gradient(circle at bottom right, rgba(120, 170, 255, 0.25), transparent 70%),
    linear-gradient(135deg, #c7dbff 0%, #dcedff 50%, #f5fbff 100%);
  position: relative;
  overflow: hidden;
}

.home-container::before {
  content: "";
  position: absolute;
  top: -20%;
  left: -20%;
  width: 140%;
  height: 140%;
  background: radial-gradient(circle at center, rgba(200, 220, 255, 0.25), transparent 70%);
  filter: blur(90px);
  pointer-events: none;
  z-index: 0;
}

.home-container::after {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-image: url('data:image/svg+xml;utf8,<svg width="120" height="120" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg"><circle fill="%23000" fill-opacity="0.005" cx="50" cy="50" r="1"/></svg>');
  background-repeat: repeat;
  pointer-events: none;
  z-index: 1;
}



.welcome {
  font-size: 22px;
  font-weight: 600;
  color: var(--primary-dark);
  margin-bottom: 40px;
  margin-top: -90px;
  user-select: none;
}

.sub-title {
  font-size: 16px;
  color: #4d6fae;
  margin-bottom: 20px;
  user-select: none;
}

button {
  width: 240px;
  padding: 14px 0;
  margin: 10px 0;
  font-size: 16px;
  color: #fff;
  background: linear-gradient(90deg, var(--primary) 0%, var(--primary-dark) 100%);
  border: none;
  border-radius: 12px;
  box-shadow: 0 6px 14px rgba(22, 109, 255, 0.25);
  font-weight: 600;
  letter-spacing: 1px;
  transition: transform 0.15s ease, box-shadow 0.15s ease;
  display: flex;
  justify-content: center;
  align-items: center;
}

button:active {
  transform: translateY(1px);
  box-shadow: 0 4px 10px rgba(22, 109, 255, 0.2);
}

.icon {
  margin-right: 8px;
}
</style>
