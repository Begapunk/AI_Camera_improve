const BASE_URL = 'http://192.168.1.4:5001'

export function http(url, method = 'GET', data = {}) {
  return new Promise((resolve, reject) => {
    uni.request({
      url   : BASE_URL + url,
      method: method,
      data  : data,
      header: { 'Content-Type': 'application/json' },
      success: res => resolve(res),
      fail   : err => reject(err)
    })
  })
}

// 登陆
export function loginApi(username, password) {
  return http('/login', 'POST', { username, password })
}

// 注册
export function registerApi (username, password) {
  return http('/register', 'POST', { username, password })
}
//分析自拍
export function uploadImageToServer(filePath) {
  return new Promise((resolve, reject) => {
    uni.uploadFile({
      url     : BASE_URL + '/analyze',
      filePath: filePath,
      name    : 'file',
      success : ({ data }) => {
        try   { resolve(JSON.parse(data)) }
        catch { reject('解析服务器响应失败') }
      },
      fail    : () => reject('上传失败，请检查网络或服务器')
    })
  })
}

//环境分析
export function analyzeEnvApi (filePath) {
  return new Promise((resolve, reject) => {
    uni.uploadFile({
      url     : BASE_URL + '/analyze-env',
      filePath: filePath,
      name    : 'file',
      success : ({ data }) => {
        try   { resolve(JSON.parse(data)) }
        catch { reject('解析服务器响应失败') }
      },
      fail    : () => reject('上传失败，请检查网络或服务器')
    })
  })
}
//模版评分
export function analyzeTemplateApi (filePath, saveAsTemplate = false) {
  return new Promise((resolve, reject) => {
    uni.uploadFile({
      url     : BASE_URL + '/analyze-template',
      filePath: filePath,
      name    : 'file',
      formData: { save_as_template: saveAsTemplate ? 'true' : 'false' },
      success : ({ data }) => {
        try   { resolve(JSON.parse(data)) }
        catch { reject('解析服务器响应失败') }
      },
      fail    : () => reject('上传失败，请检查网络或服务器')
    })
  })
}

//请求模版
export function fetchTemplateList () {
  return uni.request({
    url   : BASE_URL + '/api/templates',
    method: 'GET'
  }).then(res => res[1] ?? res)          
}
//删除模版
export function deleteTemplateApi (id) {
  return uni.request({
    url   : `${BASE_URL}/api/delete?template_id=${id}`,
    method: 'DELETE'
  }).then(res => res[1] ?? res)
}
